HomeNook example component payload
component: comskip
display name: Comskip
version: 0.82.0
bundle: uhome-dual-boot-example-001

This is a deterministic fixture for the installer examples, not a vendored
binary. Regenerate with scripts/build_example_bundles.py.
