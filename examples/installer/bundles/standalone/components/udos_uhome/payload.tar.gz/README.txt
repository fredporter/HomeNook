HomeNook example component payload
component: udos_uhome
display name: uHOME Runtime
version: 1.0.0
bundle: uhome-standalone-example-001

This is a deterministic fixture for the installer examples, not a vendored
binary. Regenerate with scripts/build_example_bundles.py.
